import React from "react";
import "./Pages.css";

const Draw = (props) => {
  return (
      <div className="draw_container">
          <p>Draw Page</p>
      </div>
  );
};

export default Draw;